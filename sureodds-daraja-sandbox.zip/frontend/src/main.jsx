import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {Wallet, Trophy, Home, Zap, Menu, X, Plus, ShieldCheck, Clock3, ChevronRight} from "lucide-react";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";
const userId = "demo-user";

const matches=[
 {league:"Premier League",time:"18:30",a:"Arsenal",b:"Chelsea",odds:["1.82","3.55","4.40"],dc:"1.24"},
 {league:"La Liga",time:"20:00",a:"Barcelona",b:"Sevilla",odds:["1.44","4.60","6.80"],dc:"1.12"},
 {league:"Serie A",time:"21:00",a:"Inter Milan",b:"Roma",odds:["1.68","3.90","5.10"],dc:"1.20"},
 {league:"Champions League",time:"22:00",a:"Real Madrid",b:"Dortmund",odds:["1.72","4.10","4.55"],dc:"1.19"}
];

function App(){
 const [tab,setTab]=useState("home"),[balance,setBalance]=useState(0),[slip,setSlip]=useState([]),[open,setOpen]=useState(false);
 const [amount,setAmount]=useState(""),[phone,setPhone]=useState(""),[depositMsg,setDepositMsg]=useState("");
 useEffect(()=>{loadWallet()},[]);
 async function loadWallet(){try{const r=await fetch(`${API}/api/wallet/${userId}`);const j=await r.json();setBalance(j.balance||0)}catch{}}
 function addBet(market){setSlip(s=>s.find(x=>x.id===market.id)?s:[...s,market])}
 async function deposit(){
   setDepositMsg("Sending STK Push...");
   try{
    const r=await fetch(`${API}/api/payments/stkpush`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId,phone,amount:Number(amount)})});
    const j=await r.json();
    setDepositMsg(j.message||j.error||"Check your phone.");
    if(j.ok) setTimeout(loadWallet,6000);
   }catch{setDepositMsg("Backend is not running. Start the backend first.")}
 }
 return <div className="app">
  <header><div className="brand"><span>Sure</span>Odds</div><div className="tag">BET SMART. WIN BIG.</div><button className="menu" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></header>
  <nav className={open?"mobile open":"mobile"}>{["home","live","sports","promos","wallet"].map(x=><button key={x} onClick={()=>{setTab(x);setOpen(false)}}>{x}</button>)}</nav>
  <main>
   <section className="hero"><div><p className="eyebrow">WELCOME TO SUREODDS</p><h1>BET ON YOUR<br/><b>FAVOURITE GAMES</b></h1><p>Fast markets, clear odds and a modern betting experience.</p><button onClick={()=>setTab("sports")}>START BETTING <ChevronRight/></button></div><div className="heroCard"><Trophy size={46}/><strong>UP TO 100%</strong><small>WELCOME BONUS</small></div></section>
   <div className="layout">
    <section className="content">
      <div className="tabs">{["home","live","sports","promos","wallet"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</div>
      {tab==="wallet"?<WalletPage balance={balance} amount={amount} setAmount={setAmount} phone={phone} setPhone={setPhone} deposit={deposit} msg={depositMsg}/>:<><div className="sectionTitle"><div><span>TOP EVENTS</span><h2>{tab==="live"?"LIVE BETTING":"POPULAR MATCHES"}</h2></div><Zap/></div>{matches.map((m,i)=><Match key={i} m={m} onAdd={addBet}/>)}</>}
    </section>
    <aside><div className="slipHead"><b>BET SLIP</b><span>{slip.length} selections</span></div>{slip.length===0?<div className="empty">Your bet slip is empty.<br/>Tap an odd to add it.</div>:slip.map(x=><div className="selection" key={x.id}><b>{x.name}</b><span>{x.odd}</span></div>)}<div className="balance"><span>Wallet balance</span><b>KES {balance.toLocaleString()}</b></div><button className="depositBtn" onClick={()=>setTab("wallet")}><Plus/> DEPOSIT FUNDS</button></aside>
   </div>
  </main>
  <footer><ShieldCheck/> Secure payments <Clock3/> Fast processing <span>18+ Responsible Gambling</span></footer>
 </div>
}
function Match({m,onAdd}){return <div className="match"><div className="matchTop"><span>{m.league}</span><small>{m.time}</small></div><div className="teams"><div><b>{m.a}</b><b>{m.b}</b></div><div className="odds">{m.odds.map((o,i)=><button key={i} onClick={()=>onAdd({id:m.a+i,name:`${m.a} vs ${m.b} • ${["Home","Draw","Away"][i]}`,odd:o})}>{["1","X","2"][i]} <strong>{o}</strong></button>)}<button onClick={()=>onAdd({id:m.a+"dc",name:`${m.a} vs ${m.b} • Double Chance`,odd:m.dc})}>DC <strong>{m.dc}</strong></button></div></div></div>}
function WalletPage(p){return <div className="walletPage"><div className="walletCard"><span>AVAILABLE BALANCE</span><strong>KES {p.balance.toLocaleString()}</strong></div><h2>Deposit with M-Pesa</h2><p className="muted">A secure Daraja STK Push will be sent to your phone.</p><label>M-Pesa number</label><input value={p.phone} onChange={e=>p.setPhone(e.target.value)} placeholder="07XXXXXXXX"/><label>Amount (KES)</label><input value={p.amount} onChange={e=>p.setAmount(e.target.value)} placeholder="100"/><button className="pay" onClick={p.deposit}>SEND STK PUSH</button>{p.msg&&<div className="msg">{p.msg}</div>}<div className="notice">Sandbox mode: no real money is moved by this starter until you configure the appropriate Daraja environment and approved business account.</div></div>}
createRoot(document.getElementById("root")).render(<App/>);
