import express from "express";
import cors from "cors";
import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const isSandbox = (process.env.DARAJA_ENV || "sandbox") !== "production";

const base = isSandbox
  ? "https://sandbox.safaricom.co.ke"
  : "https://api.safaricom.co.ke";

// Demo in-memory ledger. Replace with PostgreSQL/MySQL/SQLite for production.
const transactions = new Map();
const wallets = new Map();

function normalizePhone(phone) {
  const p = String(phone || "").replace(/\D/g, "");
  if (p.startsWith("0") && p.length === 10) return "254" + p.slice(1);
  if (p.startsWith("254") && p.length === 12) return p;
  if (p.startsWith("7") && p.length === 9) return "254" + p;
  return null;
}

function now() {
  return new Date().toISOString();
}

async function getToken() {
  const auth = Buffer.from(
    `${process.env.DARAJA_CONSUMER_KEY}:${process.env.DARAJA_CONSUMER_SECRET}`
  ).toString("base64");

  const response = await axios.get(`${base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
    timeout: 15000
  });
  return response.data.access_token;
}

function password(timestamp) {
  return Buffer.from(
    `${process.env.DARAJA_SHORTCODE}${process.env.DARAJA_PASSKEY}${timestamp}`
  ).toString("base64");
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, mode: isSandbox ? "sandbox" : "production", time: now() });
});

app.get("/api/wallet/:userId", (req, res) => {
  const wallet = wallets.get(req.params.userId) || { balance: 0 };
  res.json(wallet);
});

app.get("/api/transactions/:userId", (req, res) => {
  const rows = [...transactions.values()]
    .filter(t => t.userId === req.params.userId)
    .sort((a,b) => b.createdAt.localeCompare(a.createdAt));
  res.json(rows);
});

app.post("/api/payments/stkpush", async (req, res) => {
  try {
    const { userId = "demo-user", phone, amount } = req.body;
    const msisdn = normalizePhone(phone);
    const numericAmount = Number(amount);

    if (!msisdn) return res.status(400).json({ error: "Enter a valid Kenyan M-Pesa number." });
    if (!Number.isFinite(numericAmount) || numericAmount < 1 || numericAmount > 150000) {
      return res.status(400).json({ error: "Enter an amount between KES 1 and KES 150,000." });
    }

    const timestamp = new Date().toISOString()
      .replace(/\D/g, "").slice(0, 14);

    const token = await getToken();
    const response = await axios.post(
      `${base}/mpesa/stkpush/v1/processrequest`,
      {
        BusinessShortCode: process.env.DARAJA_SHORTCODE,
        Password: password(timestamp),
        Timestamp: timestamp,
        TransactionType: "CustomerPayBillOnline",
        Amount: Math.round(numericAmount),
        PartyA: msisdn,
        PartyB: process.env.DARAJA_SHORTCODE,
        PhoneNumber: msisdn,
        CallBackURL: process.env.DARAJA_CALLBACK_URL,
        AccountReference: process.env.DARAJA_ACCOUNT_REFERENCE || "SureOdds",
        TransactionDesc: process.env.DARAJA_TRANSACTION_DESC || "SureOdds Deposit"
      },
      { headers: { Authorization: `Bearer ${token}` }, timeout: 20000 }
    );

    const checkoutId = response.data.CheckoutRequestID || crypto.randomUUID();
    transactions.set(checkoutId, {
      id: checkoutId,
      userId,
      phone: msisdn,
      amount: Math.round(numericAmount),
      status: "pending",
      createdAt: now(),
      merchantResponse: response.data
    });

    res.json({
      ok: true,
      message: response.data.CustomerMessage || "STK Push sent. Complete the payment on your phone.",
      checkoutRequestId: checkoutId
    });
  } catch (err) {
    const detail = err.response?.data || err.message;
    console.error("STK error:", detail);
    res.status(502).json({
      error: "Daraja request failed. Check your sandbox credentials and callback URL.",
      detail: isSandbox ? detail : undefined
    });
  }
});

app.post("/api/payments/callback", (req, res) => {
  try {
    const body = req.body?.Body?.stkCallback;
    const checkoutId = body?.CheckoutRequestID;
    const tx = checkoutId ? transactions.get(checkoutId) : null;

    if (tx) {
      const success = Number(body.ResultCode) === 0;
      tx.status = success ? "completed" : "failed";
      tx.resultCode = body.ResultCode;
      tx.resultDesc = body.ResultDesc;
      tx.callbackAt = now();

      if (success) {
        const current = wallets.get(tx.userId) || { balance: 0 };
        // Idempotency guard: credit only once.
        if (!tx.credited) {
          current.balance += tx.amount;
          wallets.set(tx.userId, current);
          tx.credited = true;
        }
      }
      transactions.set(checkoutId, tx);
    }

    res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (err) {
    console.error("Callback error:", err);
    res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  }
});

app.listen(PORT, () => {
  console.log(`SureOdds API running on http://localhost:${PORT} (${isSandbox ? "sandbox" : "production"})`);
});
